const express = require("express");
const app = express();
const port = 3000;
const axios = require("axios");
const bodyParser = require("body-parser");
const fs = require("fs");
const path = require("path");

app.use(express.static("public"));
app.use(bodyParser.json());

// allow CORS
app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  next();
});

// Serve login and register pages
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});
app.get("/register", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "register.html"));
});
app.get("/dashboard", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "dashboard.html"));
});

// M-Pesa STK push route
app.post("/stkpush", async (req, res) => {
  try {
    // your M-Pesa code unchanged
    res.send("M-Pesa simulation here");
  } catch (err) {
    console.error(err);
    res.status(500).send("STK push error");
  }
});

// Register user
app.post("/register", (req, res) => {
  const { email, password } = req.body;
  fs.readFile("users.json", "utf8", (err, data) => {
    if (err) data = "[]";
    let users = JSON.parse(data);
    if (users.find(u => u.email === email)) {
      return res.status(400).send("User already exists");
    }
    users.push({ email, password });
    fs.writeFile("users.json", JSON.stringify(users), err => {
      if (err) return res.status(500).send("Server error");
      res.send("success");
    });
  });
});

// Login user
app.post("/login", (req, res) => {
  const { email, password } = req.body;
  fs.readFile("users.json", "utf8", (err, data) => {
    if (err) data = "[]";
    let users = JSON.parse(data);
    const user = users.find(u => u.email === email && u.password === password);
    if (user) {
      res.send("success");
    } else {
      res.status(401).send("Invalid credentials");
    }
  });
});

// get booked slots
app.get("/bookedslots", (req, res) => {
  fs.readFile("slots.json", "utf8", (err, data) => {
    if (err) return res.json([]);
    res.json(JSON.parse(data));
  });
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
