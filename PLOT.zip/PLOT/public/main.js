// login
const loginForm = document.getElementById('loginForm');
if (loginForm) {
  loginForm.addEventListener('submit', e => {
    e.preventDefault();
    fetch('/api/login', {
      method: 'POST',
      body: JSON.stringify({
        email: email.value,
        password: password.value
      }),
      headers: { 'Content-Type': 'application/json' }
    }).then(r => {
      if (r.ok) window.location = 'dashboard.html';
      else alert('Invalid login');
    });
  });
}

// register
const registerForm = document.getElementById('registerForm');
if (registerForm) {
  registerForm.addEventListener('submit', e => {
    e.preventDefault();
    fetch('/api/register', {
      method: 'POST',
      body: JSON.stringify({
        email: email.value,
        password: password.value
      }),
      headers: { 'Content-Type': 'application/json' }
    }).then(r => {
      if (r.ok) window.location = 'login.html';
      else alert('Email already exists');
    });
  });
}

// reset
const resetForm = document.getElementById('resetForm');
if (resetForm) {
  resetForm.addEventListener('submit', e => {
    e.preventDefault();
    fetch('/api/reset', {
      method: 'POST',
      body: JSON.stringify({
        email: email.value,
        password: password.value
      }),
      headers: { 'Content-Type': 'application/json' }
    }).then(r => {
      if (r.ok) window.location = 'login.html';
      else alert('User not found');
    });
  });
}

// dashboard
if (window.location.pathname.endsWith('dashboard.html')) {
  fetch('/api/slots')
    .then(r => r.json())
    .then(slots => {
      const slotsDiv = document.getElementById('slots');
      slotsDiv.innerHTML = '';
      slots.forEach(s => {
        const div = document.createElement('div');
        div.className = 'slot ' + s.status;

        if (s.status === 'empty') {
          div.innerHTML = `<i data-lucide="parking-square" style="color:green;width:40px;height:40px;"></i>`;
        } else if (s.status === 'booked') {
          div.innerHTML = `<i data-lucide="bookmark" style="color:grey;width:40px;height:40px;"></i>`;
        } else if (s.status === 'occupied') {
          div.innerHTML = `<i data-lucide="car" style="color:red;width:40px;height:40px;"></i>`;
        }

        div.title = `Slot ${s.id}`;
        div.onclick = () => {
          if (s.status === 'empty') {
            fetch('/api/book', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ id: s.id })
            }).then(() => location.reload());
          } else if (s.status === 'booked') {
            if (confirm('Confirm payment?')) {
              fetch('/api/confirm', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: s.id })
              }).then(() => location.reload());
            }
          }
        };
        slotsDiv.appendChild(div);
      });
      lucide.createIcons();
    });
}

function logout() {
  window.location = 'index.html';
}

